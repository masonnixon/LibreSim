
#ifndef INTEGRATION_H
#define INTEGRATION_H

#include <stddef.h>
#include <string.h>

// Get number of passes for a method (string-based for simple API)
int get_num_passes(const char* method);

// Get normalized stage-time offsets for a method
const double* get_stage_offsets(const char* method);

// Propagate a single integrator state
// Each integrator MUST provide its own x0 storage to avoid conflicts
void propagate_integrator(
    double* state,
    double* x0, double* xd0, double* xd1, double* xd2, double* xd3,
    double derivative,
    double dt, int kpass, const char* method
);

#endif // INTEGRATION_H
