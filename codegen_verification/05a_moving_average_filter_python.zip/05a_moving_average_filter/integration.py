"""Integration methods for numerical simulation."""


# Integration Methods
# ===================


def euler_propagate(integrators: list, dt: float, kpass: int) -> None:
    """Euler integration (single pass)."""
    for integ in integrators:
        integ.state += dt * integ.derivative



def rk2_propagate(integrators: list, dt: float, kpass: int) -> None:
    """RK2 (midpoint) integration."""
    for integ in integrators:
        if kpass == 0:
            integ.x0 = integ.state
            integ.xd0 = integ.derivative
            integ.state = integ.x0 + dt / 2.0 * integ.xd0
        elif kpass == 1:
            integ.xd1 = integ.derivative
            integ.state = integ.x0 + dt * integ.xd1



def rk4_propagate(integrators: list, dt: float, kpass: int) -> None:
    """RK4 (4th order Runge-Kutta) integration."""
    for integ in integrators:
        if kpass == 0:
            integ.x0 = integ.state
            integ.xd0 = integ.derivative
            integ.state = integ.x0 + dt / 2.0 * integ.xd0
        elif kpass == 1:
            integ.xd1 = integ.derivative
            integ.state = integ.x0 + dt / 2.0 * integ.xd1
        elif kpass == 2:
            integ.xd2 = integ.derivative
            integ.state = integ.x0 + dt * integ.xd2
        elif kpass == 3:
            integ.xd3 = integ.derivative
            integ.state = integ.x0 + dt / 6.0 * (
                integ.xd0 + 2.0 * integ.xd1 + 2.0 * integ.xd2 + integ.xd3
            )



def merson_propagate(integrators: list, dt: float, kpass: int) -> None:
    """Merson (4th order with error estimation) integration."""
    for integ in integrators:
        if kpass == 0:
            integ.x0 = integ.state
            integ.xd0 = integ.derivative
            integ.state = integ.x0 + dt / 3.0 * integ.xd0
        elif kpass == 1:
            integ.xd1 = integ.derivative
            integ.state = integ.x0 + dt / 6.0 * (integ.xd0 + integ.xd1)
        elif kpass == 2:
            integ.xd2 = integ.derivative
            integ.state = integ.x0 + dt / 8.0 * (integ.xd0 + 3.0 * integ.xd2)
        elif kpass == 3:
            integ.xd3 = integ.derivative
            integ.state = integ.x0 + dt / 2.0 * (integ.xd0 - 3.0 * integ.xd2 + 4.0 * integ.xd3)
        elif kpass == 4:
            integ.xd4 = integ.derivative
            integ.state = integ.x0 + dt / 6.0 * (integ.xd0 + 4.0 * integ.xd3 + integ.xd4)



def get_propagate_function(method: str):
    """Get the propagation function for an integration method."""
    methods = {
        "euler": euler_propagate,
        "rk2": rk2_propagate,
        "rk4": rk4_propagate,
        "merson": merson_propagate,
    }
    return methods.get(method.lower(), rk4_propagate)


def get_num_passes(method: str) -> int:
    """Get the number of passes for an integration method."""
    passes = {
        "euler": 1,
        "rk2": 2,
        "rk4": 4,
        "merson": 5,
    }
    return passes.get(method.lower(), 4)

