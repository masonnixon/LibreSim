
//! Integration methods for numerical simulation

/// Integration method enum
#[derive(Clone, Copy, Debug)]
pub enum IntegrationMethod {
    Euler,
    Rk2,
    Rk4,
    Merson,
}

impl IntegrationMethod {
    /// Get the number of passes for this method
    pub fn passes(&self) -> usize {
        match self {
            IntegrationMethod::Euler => 1,
            IntegrationMethod::Rk2 => 2,
            IntegrationMethod::Rk4 => 4,
            IntegrationMethod::Merson => 5,
        }
    }

    /// Parse from string
    pub fn from_str(s: &str) -> Self {
        match s.to_lowercase().as_str() {
            "euler" => IntegrationMethod::Euler,
            "rk2" => IntegrationMethod::Rk2,
            "rk4" => IntegrationMethod::Rk4,
            "merson" => IntegrationMethod::Merson,
            _ => IntegrationMethod::Rk4,  // Default
        }
    }
}

/// Get number of passes for an integration method
pub fn get_num_passes(method: IntegrationMethod) -> usize {
    method.passes()
}

/// Get normalized stage-time offsets for an integration method
pub fn get_stage_offsets(method: IntegrationMethod) -> &'static [f64] {
    match method {
        IntegrationMethod::Euler => &[0.0],
        IntegrationMethod::Rk2 => &[0.0, 0.5],
        IntegrationMethod::Rk4 => &[0.0, 0.5, 0.5, 1.0],
        IntegrationMethod::Merson => &[0.0, 1.0 / 3.0, 1.0 / 3.0, 0.5, 1.0],
    }
}

/// State for an integrator during multi-pass integration
#[derive(Clone, Default)]
pub struct IntegratorState {
    pub state: f64,
    pub derivative: f64,
    pub x0: f64,
    pub xd0: f64,
    pub xd1: f64,
    pub xd2: f64,
    pub xd3: f64,
    pub xd4: f64,
}

impl IntegratorState {
    pub fn new(initial: f64) -> Self {
        Self {
            state: initial,
            ..Default::default()
        }
    }

    /// Propagate state using the given integration method
    pub fn propagate(&mut self, dt: f64, kpass: usize, method: IntegrationMethod) {
        match method {
            IntegrationMethod::Euler => self.euler_step(dt),
            IntegrationMethod::Rk2 => self.rk2_step(dt, kpass),
            IntegrationMethod::Rk4 => self.rk4_step(dt, kpass),
            IntegrationMethod::Merson => self.merson_step(dt, kpass),
        }
    }

    fn euler_step(&mut self, dt: f64) {
        self.state += dt * self.derivative;
    }

    fn rk2_step(&mut self, dt: f64, kpass: usize) {
        match kpass {
            0 => {
                self.x0 = self.state;
                self.xd0 = self.derivative;
                self.state = self.x0 + dt / 2.0 * self.xd0;
            }
            1 => {
                self.xd1 = self.derivative;
                self.state = self.x0 + dt * self.xd1;
            }
            _ => {}
        }
    }

    fn rk4_step(&mut self, dt: f64, kpass: usize) {
        match kpass {
            0 => {
                self.x0 = self.state;
                self.xd0 = self.derivative;
                self.state = self.x0 + dt / 2.0 * self.xd0;
            }
            1 => {
                self.xd1 = self.derivative;
                self.state = self.x0 + dt / 2.0 * self.xd1;
            }
            2 => {
                self.xd2 = self.derivative;
                self.state = self.x0 + dt * self.xd2;
            }
            3 => {
                self.xd3 = self.derivative;
                self.state = self.x0 + dt / 6.0 * (
                    self.xd0 + 2.0 * self.xd1 + 2.0 * self.xd2 + self.xd3
                );
            }
            _ => {}
        }
    }

    fn merson_step(&mut self, dt: f64, kpass: usize) {
        match kpass {
            0 => {
                self.x0 = self.state;
                self.xd0 = self.derivative;
                self.state = self.x0 + dt / 3.0 * self.xd0;
            }
            1 => {
                self.xd1 = self.derivative;
                self.state = self.x0 + dt / 6.0 * (self.xd0 + self.xd1);
            }
            2 => {
                self.xd2 = self.derivative;
                self.state = self.x0 + dt / 8.0 * (self.xd0 + 3.0 * self.xd2);
            }
            3 => {
                self.xd3 = self.derivative;
                self.state = self.x0 + dt / 2.0 * (self.xd0 - 3.0*self.xd2 + 4.0*self.xd3);
            }
            4 => {
                self.xd4 = self.derivative;
                self.state = self.x0 + dt / 6.0 * (self.xd0 + 4.0*self.xd3 + self.xd4);
            }
            _ => {}
        }
    }
}

/// Propagate a single integrator state
/// Each integrator MUST provide its own x0 storage to avoid conflicts
pub fn propagate_integrator(
    state: &mut f64,
    x0: &mut f64,
    xd0: &mut f64,
    xd1: &mut f64,
    xd2: &mut f64,
    xd3: &mut f64,
    derivative: f64,
    dt: f64,
    kpass: usize,
    method: IntegrationMethod,
) {
    match method {
        IntegrationMethod::Euler => {
            *state += dt * derivative;
        }
        IntegrationMethod::Rk2 => {
            match kpass {
                0 => {
                    *x0 = *state;
                    *xd0 = derivative;
                    *state = *x0 + dt / 2.0 * *xd0;
                }
                1 => {
                    *xd1 = derivative;
                    *state = *x0 + dt * *xd1;
                }
                _ => {}
            }
        }
        IntegrationMethod::Rk4 => {
            match kpass {
                0 => {
                    *x0 = *state;
                    *xd0 = derivative;
                    *state = *x0 + dt / 2.0 * *xd0;
                }
                1 => {
                    *xd1 = derivative;
                    *state = *x0 + dt / 2.0 * *xd1;
                }
                2 => {
                    *xd2 = derivative;
                    *state = *x0 + dt * *xd2;
                }
                3 => {
                    *xd3 = derivative;
                    *state = *x0 + dt / 6.0 * (*xd0 + 2.0 * *xd1 + 2.0 * *xd2 + *xd3);
                }
                _ => {}
            }
        }
        IntegrationMethod::Merson => {
            // Static storage for xd4 only (ok to share, just derivative)
            thread_local! {
                static XD4: std::cell::RefCell<f64> = std::cell::RefCell::new(0.0);
            }
            XD4.with(|xd4_cell| {
                let mut xd4 = xd4_cell.borrow_mut();
                match kpass {
                    0 => {
                        *x0 = *state;
                        *xd0 = derivative;
                        *state = *x0 + dt / 3.0 * *xd0;
                    }
                    1 => {
                        *xd1 = derivative;
                        *state = *x0 + dt / 6.0 * (*xd0 + *xd1);
                    }
                    2 => {
                        *xd2 = derivative;
                        *state = *x0 + dt / 8.0 * (*xd0 + 3.0 * *xd2);
                    }
                    3 => {
                        *xd3 = derivative;
                        *state = *x0 + dt / 2.0 * (*xd0 - 3.0 * *xd2 + 4.0 * *xd3);
                    }
                    4 => {
                        *xd4 = derivative;
                        *state = *x0 + dt / 6.0 * (*xd0 + 4.0 * *xd3 + *xd4);
                    }
                    _ => {}
                }
            });
        }
    }
}
