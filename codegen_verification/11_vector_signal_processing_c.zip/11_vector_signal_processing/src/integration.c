
#include "integration.h"

int get_num_passes(const char* method) {
    if (strcmp(method, "euler") == 0) return 1;
    if (strcmp(method, "rk2") == 0) return 2;
    if (strcmp(method, "rk4") == 0) return 4;
    if (strcmp(method, "merson") == 0) return 5;
    return 4;  // Default to RK4
}

void propagate_integrator(
    double* state,
    double* x0, double* xd0, double* xd1, double* xd2, double* xd3,
    double derivative,
    double dt, int kpass, const char* method
) {
    // Static storage for merson xd4 only (ok to share, just derivative)
    static double s_xd4 = 0.0;
    if (strcmp(method, "euler") == 0) {
        *state += dt * derivative;
    } else if (strcmp(method, "rk2") == 0) {
        if (kpass == 0) {
            *x0 = *state;
            *xd0 = derivative;
            *state = *x0 + dt / 2.0 * (*xd0);
        } else if (kpass == 1) {
            *xd1 = derivative;
            *state = *x0 + dt * (*xd1);
        }
    } else if (strcmp(method, "rk4") == 0) {
        if (kpass == 0) {
            *x0 = *state;
            *xd0 = derivative;
            *state = *x0 + dt / 2.0 * (*xd0);
        } else if (kpass == 1) {
            *xd1 = derivative;
            *state = *x0 + dt / 2.0 * (*xd1);
        } else if (kpass == 2) {
            *xd2 = derivative;
            *state = *x0 + dt * (*xd2);
        } else if (kpass == 3) {
            *xd3 = derivative;
            *state = *x0 + dt / 6.0 * ((*xd0) + 2.0*(*xd1) + 2.0*(*xd2) + (*xd3));
        }
    } else if (strcmp(method, "merson") == 0) {
        if (kpass == 0) {
            *x0 = *state;
            *xd0 = derivative;
            *state = *x0 + dt / 3.0 * (*xd0);
        } else if (kpass == 1) {
            *xd1 = derivative;
            *state = *x0 + dt / 6.0 * ((*xd0) + (*xd1));
        } else if (kpass == 2) {
            *xd2 = derivative;
            *state = *x0 + dt / 8.0 * ((*xd0) + 3.0 * (*xd2));
        } else if (kpass == 3) {
            *xd3 = derivative;
            *state = *x0 + dt / 2.0 * ((*xd0) - 3.0*(*xd2) + 4.0*(*xd3));
        } else if (kpass == 4) {
            s_xd4 = derivative;
            *state = *x0 + dt / 6.0 * ((*xd0) + 4.0*(*xd3) + s_xd4);
        }
    } else {
        // Default to RK4
        propagate_integrator(state, x0, xd0, xd1, xd2, xd3, derivative, dt, kpass, "rk4");
    }
}
